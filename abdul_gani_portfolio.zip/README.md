# Abdul Gani Portfolio Website

This is the personal portfolio site for Abdul Gani (Matric: 2013961), Year 3 BBA student at IIUM, created for the USRAH 1 assignment.

## Contents
- `index.html`: Main website with Golden Age Islamic theme
- `README.md`: This file

## Deployment
Upload `index.html` to a public GitHub repository and enable GitHub Pages from the repository Settings > Pages tab. Make sure the source is set to `main` and folder is `/ (root)`.

## Author
Abdul Gani bin Mohamed Iqbal
LinkedIn: https://www.linkedin.com/in/abdul-gani-570573170/
